/**
 * 运行包一键启动（已含打包产物与 node_modules，无需再 npm install）
 */
import { spawn, exec } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import http from 'node:http'
import { fileURLToPath } from 'node:url'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const PORT = Number(process.env.ACW_PORT || 3780)
const AUTO_EXIT = process.env.ACW_AUTO_EXIT !== '0' && process.env.ACW_AUTO_EXIT !== 'false'
const ENTRY = path.join(ROOT, 'server', 'dist', 'index.cjs')

function log(...a) {
  console.log('[acw-start]', ...a)
}

function waitHealth(timeoutMs = 60_000) {
  const started = Date.now()
  return new Promise((resolve, reject) => {
    const tick = () => {
      const req = http.get(`http://127.0.0.1:${PORT}/api/health`, (res) => {
        res.resume()
        if (res.statusCode === 200) return resolve()
        retry()
      })
      req.on('error', retry)
      req.setTimeout(2000, () => {
        req.destroy()
        retry()
      })
    }
    const retry = () => {
      if (Date.now() - started > timeoutMs) {
        reject(new Error('等待服务启动超时'))
        return
      }
      setTimeout(tick, 400)
    }
    tick()
  })
}

function openBrowser(url) {
  const plat = process.platform
  if (plat === 'win32') exec(`start "" "${url}"`)
  else if (plat === 'darwin') exec(`open "${url}"`)
  else exec(`xdg-open "${url}"`)
}

if (!fs.existsSync(ENTRY)) {
  console.error('[acw-start] 缺少打包入口 server/dist/index.cjs，请使用官方运行包')
  process.exit(1)
}
if (!fs.existsSync(path.join(ROOT, 'node_modules', 'better-sqlite3'))) {
  console.error('[acw-start] 缺少内置依赖 node_modules/better-sqlite3（运行包应已自带，勿删）')
  process.exit(1)
}

const env = {
  ...process.env,
  ACW_PORT: String(PORT),
  ACW_AUTO_EXIT: AUTO_EXIT ? '1' : '0',
}
log('运行包启动', ROOT)
log(`端口 :${PORT}  auto-exit=${AUTO_EXIT ? 'on' : 'off'}`)
const child = spawn(process.execPath, [ENTRY], { cwd: ROOT, env, stdio: 'inherit' })
const shutdown = () => {
  try {
    child.kill('SIGTERM')
  } catch {
    /* ignore */
  }
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
child.on('exit', (code) => process.exit(code || 0))

waitHealth()
  .then(() => {
    const url = `http://127.0.0.1:${PORT}/`
    log('打开浏览器', url)
    if (AUTO_EXIT) log('提示：关闭浏览器窗口后，后台将在数秒内自动退出')
    openBrowser(url)
  })
  .catch((e) => {
    log(e.message)
    shutdown()
    process.exit(1)
  })
