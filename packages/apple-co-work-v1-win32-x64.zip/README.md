# apple-co-work 运行包

版本：1.0.0-dev · 平台：win32-x64 · 提交：5332e29

本压缩包是**打包后的可运行程序**（不是源码仓库）。

## 需要

- 本机已安装 Node.js ≥ 18（https://nodejs.org）
- **不需要**再执行 npm install（依赖已打进包内）

## 启动

| 系统 | 操作 |
|------|------|
| Windows | 双击 start.bat |
| macOS / Linux | ./start.sh 或 node start.mjs |

关闭浏览器后，后台默认自动退出。

数据目录：解压目录下的 data/
