# apple-co-work 运行包

版本：1.2.0 · 平台：darwin-arm64 · 提交：0f2ed0f

本压缩包是**打包后的可运行程序**（不是源码仓库）。

## 需要

- 本机已安装 Node.js ≥ 18（https://nodejs.org；推荐 Node 22+）
- **通常不需要**再执行 npm install（依赖已打进包内）
- Node 22+：即使 better-sqlite3 与本机 Node 不匹配，也会自动用内置 sqlite 启动

## 启动

| 系统 | 操作 |
|------|------|
| Windows | 双击 start.bat |
| macOS / Linux | ./start.sh 或 node start.mjs |

关闭浏览器不会自动停服务；请在启动窗口 Ctrl+C 结束。

数据目录：解压目录下的 data/
