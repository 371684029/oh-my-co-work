# oh-my-co-work 运行包

版本：5.3.0 · 平台：win32-x64 · 提交：bc8bdb4836bed8493bdc318c2a110c4c4a9b7659

本压缩包是**打包后的可运行程序**（不是源码仓库）。

## 需要

- 本机已安装 Node.js ≥ 18（https://nodejs.org；推荐 Node 22+）
- **通常不需要**再执行 npm install（依赖已打进包内）
- Node 22+：即使 better-sqlite3 与本机 Node 不匹配，也会自动用内置 sqlite 启动

## 启动

| 系统 | 操作 |
|------|------|
| Windows | 双击 start.bat（需本机 Node.js；会打开浏览器） |
| macOS / Linux | ./start.sh 或 node start.mjs |

关闭浏览器不会自动停服务；请在启动窗口 Ctrl+C 结束。

数据目录：解压目录下的 data/
