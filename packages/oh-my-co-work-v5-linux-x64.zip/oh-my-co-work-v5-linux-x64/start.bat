@echo off
cd /d "%~dp0."
if not exist "data" mkdir data
echo [%date% %time%] start.bat cwd=%CD%>> data\desktop-launch.log
if exist "desktop\oh-my-co-work.exe" if exist "runtime\node.exe" if exist "desktop-launch.mjs" (
  echo [%date% %time%] node desktop-launch.mjs>> data\desktop-launch.log
  "runtime\node.exe" "desktop-launch.mjs"
  if errorlevel 1 (
    echo [acw] Desktop window failed to start.
    echo [acw] See data\electron.log and data\desktop-launch.log
    if exist "data\electron.log" type "data\electron.log"
    pause
    exit /b 1
  )
  exit /b 0
)
if exist "desktop\electron.exe" if exist "runtime\node.exe" if exist "desktop-launch.mjs" (
  echo [%date% %time%] node desktop-launch.mjs>> data\desktop-launch.log
  "runtime\node.exe" "desktop-launch.mjs"
  if errorlevel 1 (
    echo [acw] Desktop window failed to start.
    echo [acw] See data\electron.log and data\desktop-launch.log
    if exist "data\electron.log" type "data\electron.log"
    pause
    exit /b 1
  )
  exit /b 0
)
if exist "runtime\node.exe" (
  echo [acw] starting oh-my-co-work (bundled Node, no npm install)...
  "runtime\node.exe" start.mjs
  if errorlevel 1 pause
  exit /b %errorlevel%
)
where node >nul 2>nul
if errorlevel 1 (
  echo [acw] Node.js not found. Please install Node.js 18+ from https://nodejs.org
  pause
  exit /b 1
)
echo [acw] starting oh-my-co-work (no npm install needed)...
echo [acw] Close this window to stop the server.
node start.mjs
if errorlevel 1 pause
