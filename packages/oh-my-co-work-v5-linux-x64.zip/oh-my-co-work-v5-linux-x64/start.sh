#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# 桌面包（win32/linux/darwin 通用布局）：优先用包内 node 拉起桌面窗口
if [ -f desktop-launch.mjs ] && [ -x runtime/node ] && [ -d desktop ]; then
  echo "[acw] 正在启动 oh-my-co-work 桌面窗口…"
  echo "[acw] 提示：关闭窗口默认藏托盘，托盘「退出」才停服务"
  exec ./runtime/node desktop-launch.mjs
fi
if ! command -v node >/dev/null 2>&1; then
  echo "[acw] 未检测到 Node.js，请先安装 Node.js 18+ ：https://nodejs.org"
  exit 1
fi
echo "[acw] 正在启动 oh-my-co-work（运行包，无需 npm install）…"
echo "[acw] 提示：关闭本窗口或 Ctrl+C 即可结束服务（关浏览器不会停）"
exec node start.mjs
